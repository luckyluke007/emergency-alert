Welcome to Neat! 👋🎉

Do you need help or have a question? Please check out Neat on [Stack Overflow]. Got an idea for a new feature or found a bug? Please fill out the sections below... thank you 👍

[Stack Overflow]: https://stackoverflow.com/questions/tagged/neat

### Issue Summary

A summary of the issue and the browser/OS environment in which it occurs.

### Steps to Reproduce

1. This is the first step
2. This is the second step, etc.

Any other info, for example, why you consider this to be a bug? What did you expect to happen instead?

### Technical details:

- Neat Version:
- Build Tool or Environment:
- Browser/OS:
